# Settlement approval: Invalid / boundary input

TAP demonstration model. Not FWD internal documentation, source code or production behavior. No real customer data. 

Priority: P0
Precondition: authorised demo user and an isolated synthetic policy.
Input: approved = false
Steps: open cl-settlement; submit the request; inspect response, stored revision and audit events.
Expected: Never create a payment instruction for an unapproved claim.
Evidence: redacted response, before/after revision and correlated event IDs.
Status: designed; no real FWD execution performed.