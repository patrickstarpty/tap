# Policy document access: Invalid / boundary input

TAP demonstration model. Not FWD internal documentation, source code or production behavior. No real customer data. 

Priority: P0
Precondition: authorised demo user and an isolated synthetic policy.
Input: ownsPolicy = false
Steps: open ps-statement; submit the request; inspect response, stored revision and audit events.
Expected: Deny another policyholder's document and emit no document bytes.
Evidence: redacted response, before/after revision and correlated event IDs.
Status: designed; no real FWD execution performed.