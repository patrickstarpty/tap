# Critical illness routing: Invalid / boundary input

TAP demonstration model. Not FWD internal documentation, source code or production behavior. No real customer data. 

Priority: P0
Precondition: authorised demo user and an isolated synthetic policy.
Input: claimType = "unknown"
Steps: open cl-critical; submit the request; inspect response, stored revision and audit events.
Expected: Route by claim type and do not substitute a medical-expense decision.
Evidence: redacted response, before/after revision and correlated event IDs.
Status: designed; no real FWD execution performed.