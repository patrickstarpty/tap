# Contact change: Invalid / boundary input

TAP demonstration model. Not FWD internal documentation, source code or production behavior. No real customer data. 

Priority: P0
Precondition: authorised demo user and an isolated synthetic policy.
Input: verified = false
Steps: open ps-contact; submit the request; inspect response, stored revision and audit events.
Expected: An unverified update must not replace the existing contact record.
Evidence: redacted response, before/after revision and correlated event IDs.
Status: designed; no real FWD execution performed.