# Beneficiary allocation: Invalid / boundary input

TAP demonstration model. Not FWD internal documentation, source code or production behavior. No real customer data. 

Priority: P0
Precondition: authorised demo user and an isolated synthetic policy.
Input: allocationTotal = 99
Steps: open ps-beneficiary; submit the request; inspect response, stored revision and audit events.
Expected: Demo rule: allocations must total 100; reject 99 or 101 without changing the policy.
Evidence: redacted response, before/after revision and correlated event IDs.
Status: designed; no real FWD execution performed.