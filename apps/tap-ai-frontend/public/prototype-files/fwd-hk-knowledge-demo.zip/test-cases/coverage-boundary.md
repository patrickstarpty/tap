# Coverage version: Invalid / boundary input

TAP demonstration model. Not FWD internal documentation, source code or production behavior. No real customer data. 

Priority: P0
Precondition: authorised demo user and an isolated synthetic policy.
Input: policyVersion = null
Steps: open cl-coverage; submit the request; inspect response, stored revision and audit events.
Expected: Never assess coverage against an unknown policy version.
Evidence: redacted response, before/after revision and correlated event IDs.
Status: designed; no real FWD execution performed.