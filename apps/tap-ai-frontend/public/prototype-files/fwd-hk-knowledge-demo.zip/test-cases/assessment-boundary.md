# Assessment evidence: Invalid / boundary input

TAP demonstration model. Not FWD internal documentation, source code or production behavior. No real customer data. 

Priority: P0
Precondition: authorised demo user and an isolated synthetic policy.
Input: complete = false
Steps: open cl-assessment; submit the request; inspect response, stored revision and audit events.
Expected: Do not approve a claim whose required evidence is incomplete.
Evidence: redacted response, before/after revision and correlated event IDs.
Status: designed; no real FWD execution performed.