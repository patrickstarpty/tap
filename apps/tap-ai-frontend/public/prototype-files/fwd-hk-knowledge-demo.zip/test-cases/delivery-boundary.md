# Policy acknowledgement: Invalid / boundary input

TAP demonstration model. Not FWD internal documentation, source code or production behavior. No real customer data. 

Priority: P0
Precondition: authorised demo user and an isolated synthetic policy.
Input: documentVersion = 0
Steps: open nb-delivery; submit the request; inspect response, stored revision and audit events.
Expected: Record acknowledgement only for the delivered document version.
Evidence: redacted response, before/after revision and correlated event IDs.
Status: designed; no real FWD execution performed.