# Withdrawal quotation: Invalid / boundary input

TAP demonstration model. Not FWD internal documentation, source code or production behavior. No real customer data. 

Priority: P0
Precondition: authorised demo user and an isolated synthetic policy.
Input: quoteVersion = 3
Steps: open ps-withdrawal; submit the request; inspect response, stored revision and audit events.
Expected: Reject an outdated quotation; ask for a fresh one before approval.
Evidence: redacted response, before/after revision and correlated event IDs.
Status: designed; no real FWD execution performed.