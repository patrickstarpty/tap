# Uncertain health answer: Invalid / boundary input

TAP demonstration model. Not FWD internal documentation, source code or production behavior. No real customer data. 

Priority: P0
Precondition: authorised demo user and an isolated synthetic policy.
Input: reviewRequired = null
Steps: open nb-disclosure; submit the request; inspect response, stored revision and audit events.
Expected: Preserve the original disclosure and require a reviewer; never auto-approve uncertainty.
Evidence: redacted response, before/after revision and correlated event IDs.
Status: designed; no real FWD execution performed.