# Accident claim context: Valid input

TAP demonstration model. Not FWD internal documentation, source code or production behavior. No real customer data. 

Priority: P1
Precondition: authorised demo user and an isolated synthetic policy.
Input: accidentDate = "2026-08-12"
Steps: open cl-accident; submit the request; inspect response, stored revision and audit events.
Expected: Accept for demo review; this is not policy or claim approval.
Evidence: redacted response, before/after revision and correlated event IDs.
Status: designed; no real FWD execution performed.