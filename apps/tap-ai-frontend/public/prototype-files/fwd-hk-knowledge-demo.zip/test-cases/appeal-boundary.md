# Appeal audit history: Invalid / boundary input

TAP demonstration model. Not FWD internal documentation, source code or production behavior. No real customer data. 

Priority: P0
Precondition: authorised demo user and an isolated synthetic policy.
Input: originalDecisionId = ""
Steps: open cl-appeal; submit the request; inspect response, stored revision and audit events.
Expected: Preserve and reference the prior decision when new evidence is submitted.
Evidence: redacted response, before/after revision and correlated event IDs.
Status: designed; no real FWD execution performed.