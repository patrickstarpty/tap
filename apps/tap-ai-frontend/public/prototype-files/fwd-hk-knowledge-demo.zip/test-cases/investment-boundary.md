# Investment instruction: Invalid / boundary input

TAP demonstration model. Not FWD internal documentation, source code or production behavior. No real customer data. 

Priority: P0
Precondition: authorised demo user and an isolated synthetic policy.
Input: instructionTotal = 101
Steps: open ps-investment; submit the request; inspect response, stored revision and audit events.
Expected: Demo rule: allocation must total 100 before queuing the instruction.
Evidence: redacted response, before/after revision and correlated event IDs.
Status: designed; no real FWD execution performed.