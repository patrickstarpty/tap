# Claimant authority: Invalid / boundary input

TAP demonstration model. Not FWD internal documentation, source code or production behavior. No real customer data. 

Priority: P0
Precondition: authorised demo user and an isolated synthetic policy.
Input: authorityReviewed = false
Steps: open cl-death; submit the request; inspect response, stored revision and audit events.
Expected: Hold a death claim for review when claimant authority is unresolved.
Evidence: redacted response, before/after revision and correlated event IDs.
Status: designed; no real FWD execution performed.