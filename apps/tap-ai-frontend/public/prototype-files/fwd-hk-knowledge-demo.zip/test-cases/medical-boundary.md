# Medical evidence: Invalid / boundary input

TAP demonstration model. Not FWD internal documentation, source code or production behavior. No real customer data. 

Priority: P0
Precondition: authorised demo user and an isolated synthetic policy.
Input: receiptAttached = false
Steps: open cl-medical; submit the request; inspect response, stored revision and audit events.
Expected: Keep missing-receipt claims pending evidence; do not infer an amount.
Evidence: redacted response, before/after revision and correlated event IDs.
Status: designed; no real FWD execution performed.