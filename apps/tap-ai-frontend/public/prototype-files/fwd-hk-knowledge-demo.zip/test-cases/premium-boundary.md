# Premium callback: Invalid / boundary input

TAP demonstration model. Not FWD internal documentation, source code or production behavior. No real customer data. 

Priority: P0
Precondition: authorised demo user and an isolated synthetic policy.
Input: paymentReference = ""
Steps: open nb-payment; submit the request; inspect response, stored revision and audit events.
Expected: Reject an empty reference and do not issue a policy before reconciliation.
Evidence: redacted response, before/after revision and correlated event IDs.
Status: designed; no real FWD execution performed.