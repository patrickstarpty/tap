# Reinstatement request: Invalid / boundary input

TAP demonstration model. Not FWD internal documentation, source code or production behavior. No real customer data. 

Priority: P0
Precondition: authorised demo user and an isolated synthetic policy.
Input: reviewApproved = false
Steps: open ps-reinstatement; submit the request; inspect response, stored revision and audit events.
Expected: Keep the policy lapsed until the review is approved.
Evidence: redacted response, before/after revision and correlated event IDs.
Status: designed; no real FWD execution performed.