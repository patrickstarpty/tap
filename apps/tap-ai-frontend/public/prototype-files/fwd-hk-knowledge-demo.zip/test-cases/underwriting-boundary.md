# Underwriting decision: Invalid / boundary input

TAP demonstration model. Not FWD internal documentation, source code or production behavior. No real customer data. 

Priority: P0
Precondition: authorised demo user and an isolated synthetic policy.
Input: evidenceVersion = null
Steps: open nb-underwriting; submit the request; inspect response, stored revision and audit events.
Expected: Reject a decision without an evidence version and keep review pending.
Evidence: redacted response, before/after revision and correlated event IDs.
Status: designed; no real FWD execution performed.