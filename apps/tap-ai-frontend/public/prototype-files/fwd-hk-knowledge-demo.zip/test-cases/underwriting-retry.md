# Underwriting decision: Repeated submission

TAP demonstration model. Not FWD internal documentation, source code or production behavior. No real customer data. 

Priority: P0
Precondition: authorised demo user and an isolated synthetic policy.
Input: evidenceVersion = 3
Steps: open nb-underwriting; submit the request; retry with the same requestId; inspect response, stored revision and audit events.
Expected: Use the same request identifier twice; return the same response and produce one mutation.
Evidence: redacted response, before/after revision and correlated event IDs.
Status: designed; no real FWD execution performed.