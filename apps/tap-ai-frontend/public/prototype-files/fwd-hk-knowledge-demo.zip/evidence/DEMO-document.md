# DEMO finding: Cross-policy document reference

TAP demonstration model. Not FWD internal documentation, source code or production behavior. No real customer data. 

A fictional document lookup checked existence but omitted ownership. Re-authorise every download.

Status: illustrative historical finding, not an observed FWD defect.
Investigation: reproduce in an isolated fixture, inspect the request ID and event count, add a regression test, and review transaction boundaries.
The adjacent code sketch illustrates one guard; it is not a production fix.