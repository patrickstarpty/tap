# DEMO finding: Repeated premium callback

TAP demonstration model. Not FWD internal documentation, source code or production behavior. No real customer data. 

A fictional callback created a second issuance event. Reconcile before issue and enforce a durable idempotency key.

Status: illustrative historical finding, not an observed FWD defect.
Investigation: reproduce in an isolated fixture, inspect the request ID and event count, add a regression test, and review transaction boundaries.
The adjacent code sketch illustrates one guard; it is not a production fix.