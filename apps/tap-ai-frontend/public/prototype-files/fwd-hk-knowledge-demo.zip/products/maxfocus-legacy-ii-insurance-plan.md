# MaxFocus Legacy II Insurance Plan

Public product / series reference · reviewed 2026-09-06

Category: Savings & retirement
Source: https://www.fwd.com.hk/en/savings/maxfocus-legacy-ii-insurance-plan/
Directory: https://www.fwd.com.hk/en/products/

Listed in the public product directory on 2026-09-06; individual plan and channel availability requires confirmation.

This record indexes the product and its public page. It does not reproduce policy wording or confirm suitability, eligibility, exclusions, rates or benefits. Lifecycle and software links in this demo are illustrative mappings, not verified product-specific processing rules.