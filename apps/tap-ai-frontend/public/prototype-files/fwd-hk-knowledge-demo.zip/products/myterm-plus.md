# MyTerm Plus Term Life Insurance Plan

Public product / series reference · reviewed 2026-09-06

Category: Life protection
Source: https://www.fwd.com.hk/online-insurance/term-life/en/
Directory: https://www.fwd.com.hk/online-insurance/en/

Online product referenced by the official online catalogue; this may be a version within a series, not an additional distinct insurance contract.

This record indexes the product and its public page. It does not reproduce policy wording or confirm suitability, eligibility, exclusions, rates or benefits. Lifecycle and software links in this demo are illustrative mappings, not verified product-specific processing rules.