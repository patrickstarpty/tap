// TAP demonstration model. Not FWD internal documentation, source code or production behavior. No real customer data. 
// Executable unit-test sketch for the adjacent demo handler; not a FWD integration test.
import { expect, test } from "vitest";
import { handle } from "../services/policy/coverage";

test("Coverage version: valid input", () => {
  expect(handle({requestId:"demo-coverage-valid",policyVersion:5}).status).toBe("accepted_for_demo_review");
});
test("Coverage version: invalid input", () => {
  expect(() => handle({requestId:"demo-coverage-invalid",policyVersion:null})).toThrow();
});
test("Coverage version: repeated submission", () => {
  const input = {requestId:"demo-coverage-retry",policyVersion:5};
  expect(handle(input)).toBe(handle(input));
});
