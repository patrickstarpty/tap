// TAP demonstration model. Not FWD internal documentation, source code or production behavior. No real customer data. 
// Executable unit-test sketch for the adjacent demo handler; not a FWD integration test.
import { expect, test } from "vitest";
import { handle } from "../services/claims/assessment";

test("Assessment evidence: valid input", () => {
  expect(handle({requestId:"demo-assessment-valid",complete:true}).status).toBe("accepted_for_demo_review");
});
test("Assessment evidence: invalid input", () => {
  expect(() => handle({requestId:"demo-assessment-invalid",complete:false})).toThrow();
});
test("Assessment evidence: repeated submission", () => {
  const input = {requestId:"demo-assessment-retry",complete:true};
  expect(handle(input)).toBe(handle(input));
});
