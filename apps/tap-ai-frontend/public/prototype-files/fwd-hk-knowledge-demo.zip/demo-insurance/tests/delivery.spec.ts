// TAP demonstration model. Not FWD internal documentation, source code or production behavior. No real customer data. 
// Executable unit-test sketch for the adjacent demo handler; not a FWD integration test.
import { expect, test } from "vitest";
import { handle } from "../services/documents/delivery";

test("Policy acknowledgement: valid input", () => {
  expect(handle({requestId:"demo-delivery-valid",documentVersion:2}).status).toBe("accepted_for_demo_review");
});
test("Policy acknowledgement: invalid input", () => {
  expect(() => handle({requestId:"demo-delivery-invalid",documentVersion:0})).toThrow();
});
test("Policy acknowledgement: repeated submission", () => {
  const input = {requestId:"demo-delivery-retry",documentVersion:2};
  expect(handle(input)).toBe(handle(input));
});
