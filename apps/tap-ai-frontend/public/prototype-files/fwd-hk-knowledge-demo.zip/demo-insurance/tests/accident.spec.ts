// TAP demonstration model. Not FWD internal documentation, source code or production behavior. No real customer data. 
// Executable unit-test sketch for the adjacent demo handler; not a FWD integration test.
import { expect, test } from "vitest";
import { handle } from "../services/claims/accident";

test("Accident claim context: valid input", () => {
  expect(handle({requestId:"demo-accident-valid",accidentDate:"2026-08-12"}).status).toBe("accepted_for_demo_review");
});
test("Accident claim context: invalid input", () => {
  expect(() => handle({requestId:"demo-accident-invalid",accidentDate:""})).toThrow();
});
test("Accident claim context: repeated submission", () => {
  const input = {requestId:"demo-accident-retry",accidentDate:"2026-08-12"};
  expect(handle(input)).toBe(handle(input));
});
