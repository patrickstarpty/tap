// TAP demonstration model. Not FWD internal documentation, source code or production behavior. No real customer data. 
// Executable unit-test sketch for the adjacent demo handler; not a FWD integration test.
import { expect, test } from "vitest";
import { handle } from "../services/documents/medical";

test("Medical evidence: valid input", () => {
  expect(handle({requestId:"demo-medical-valid",receiptAttached:true}).status).toBe("accepted_for_demo_review");
});
test("Medical evidence: invalid input", () => {
  expect(() => handle({requestId:"demo-medical-invalid",receiptAttached:false})).toThrow();
});
test("Medical evidence: repeated submission", () => {
  const input = {requestId:"demo-medical-retry",receiptAttached:true};
  expect(handle(input)).toBe(handle(input));
});
