// TAP demonstration model. Not FWD internal documentation, source code or production behavior. No real customer data. 
// Executable unit-test sketch for the adjacent demo handler; not a FWD integration test.
import { expect, test } from "vitest";
import { handle } from "../services/portal/contact";

test("Contact change: valid input", () => {
  expect(handle({requestId:"demo-contact-valid",verified:true}).status).toBe("accepted_for_demo_review");
});
test("Contact change: invalid input", () => {
  expect(() => handle({requestId:"demo-contact-invalid",verified:false})).toThrow();
});
test("Contact change: repeated submission", () => {
  const input = {requestId:"demo-contact-retry",verified:true};
  expect(handle(input)).toBe(handle(input));
});
