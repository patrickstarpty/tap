// TAP demonstration model. Not FWD internal documentation, source code or production behavior. No real customer data. 
// Executable unit-test sketch for the adjacent demo handler; not a FWD integration test.
import { expect, test } from "vitest";
import { handle } from "../services/audit/appeal";

test("Appeal audit history: valid input", () => {
  expect(handle({requestId:"demo-appeal-valid",originalDecisionId:"demo-decision-001"}).status).toBe("accepted_for_demo_review");
});
test("Appeal audit history: invalid input", () => {
  expect(() => handle({requestId:"demo-appeal-invalid",originalDecisionId:""})).toThrow();
});
test("Appeal audit history: repeated submission", () => {
  const input = {requestId:"demo-appeal-retry",originalDecisionId:"demo-decision-001"};
  expect(handle(input)).toBe(handle(input));
});
