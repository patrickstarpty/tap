// TAP demonstration model. Not FWD internal documentation, source code or production behavior. No real customer data. 
// Executable unit-test sketch for the adjacent demo handler; not a FWD integration test.
import { expect, test } from "vitest";
import { handle } from "../services/identity/death";

test("Claimant authority: valid input", () => {
  expect(handle({requestId:"demo-death-valid",authorityReviewed:true}).status).toBe("accepted_for_demo_review");
});
test("Claimant authority: invalid input", () => {
  expect(() => handle({requestId:"demo-death-invalid",authorityReviewed:false})).toThrow();
});
test("Claimant authority: repeated submission", () => {
  const input = {requestId:"demo-death-retry",authorityReviewed:true};
  expect(handle(input)).toBe(handle(input));
});
