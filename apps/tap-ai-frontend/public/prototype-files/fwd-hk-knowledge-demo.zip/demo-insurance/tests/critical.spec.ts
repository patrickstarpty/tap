// TAP demonstration model. Not FWD internal documentation, source code or production behavior. No real customer data. 
// Executable unit-test sketch for the adjacent demo handler; not a FWD integration test.
import { expect, test } from "vitest";
import { handle } from "../services/claims/critical";

test("Critical illness routing: valid input", () => {
  expect(handle({requestId:"demo-critical-valid",claimType:"critical-illness"}).status).toBe("accepted_for_demo_review");
});
test("Critical illness routing: invalid input", () => {
  expect(() => handle({requestId:"demo-critical-invalid",claimType:"unknown"})).toThrow();
});
test("Critical illness routing: repeated submission", () => {
  const input = {requestId:"demo-critical-retry",claimType:"critical-illness"};
  expect(handle(input)).toBe(handle(input));
});
