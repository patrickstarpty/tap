// TAP demonstration model. Not FWD internal documentation, source code or production behavior. No real customer data. 
// Executable unit-test sketch for the adjacent demo handler; not a FWD integration test.
import { expect, test } from "vitest";
import { handle } from "../services/application/issuance";

test("Policy issue transition: valid input", () => {
  expect(handle({requestId:"demo-issuance-valid",approved:true}).status).toBe("accepted_for_demo_review");
});
test("Policy issue transition: invalid input", () => {
  expect(() => handle({requestId:"demo-issuance-invalid",approved:false})).toThrow();
});
test("Policy issue transition: repeated submission", () => {
  const input = {requestId:"demo-issuance-retry",approved:true};
  expect(handle(input)).toBe(handle(input));
});
