// TAP demonstration model. Not FWD internal documentation, source code or production behavior. No real customer data. 
// Executable unit-test sketch for the adjacent demo handler; not a FWD integration test.
import { expect, test } from "vitest";
import { handle } from "../services/investment/investment";

test("Investment instruction: valid input", () => {
  expect(handle({requestId:"demo-investment-valid",instructionTotal:100}).status).toBe("accepted_for_demo_review");
});
test("Investment instruction: invalid input", () => {
  expect(() => handle({requestId:"demo-investment-invalid",instructionTotal:101})).toThrow();
});
test("Investment instruction: repeated submission", () => {
  const input = {requestId:"demo-investment-retry",instructionTotal:100};
  expect(handle(input)).toBe(handle(input));
});
