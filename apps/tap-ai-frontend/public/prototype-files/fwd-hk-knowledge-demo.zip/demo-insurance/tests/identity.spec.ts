// TAP demonstration model. Not FWD internal documentation, source code or production behavior. No real customer data. 
// Executable unit-test sketch for the adjacent demo handler; not a FWD integration test.
import { expect, test } from "vitest";
import { handle } from "../services/identity/identity";

test("Applicant evidence: valid input", () => {
  expect(handle({requestId:"demo-identity-valid",consent:true}).status).toBe("accepted_for_demo_review");
});
test("Applicant evidence: invalid input", () => {
  expect(() => handle({requestId:"demo-identity-invalid",consent:false})).toThrow();
});
test("Applicant evidence: repeated submission", () => {
  const input = {requestId:"demo-identity-retry",consent:true};
  expect(handle(input)).toBe(handle(input));
});
