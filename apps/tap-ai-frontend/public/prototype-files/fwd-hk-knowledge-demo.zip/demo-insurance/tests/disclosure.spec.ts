// TAP demonstration model. Not FWD internal documentation, source code or production behavior. No real customer data. 
// Executable unit-test sketch for the adjacent demo handler; not a FWD integration test.
import { expect, test } from "vitest";
import { handle } from "../services/application/disclosure";

test("Uncertain health answer: valid input", () => {
  expect(handle({requestId:"demo-disclosure-valid",reviewRequired:true}).status).toBe("accepted_for_demo_review");
});
test("Uncertain health answer: invalid input", () => {
  expect(() => handle({requestId:"demo-disclosure-invalid",reviewRequired:null})).toThrow();
});
test("Uncertain health answer: repeated submission", () => {
  const input = {requestId:"demo-disclosure-retry",reviewRequired:true};
  expect(handle(input)).toBe(handle(input));
});
