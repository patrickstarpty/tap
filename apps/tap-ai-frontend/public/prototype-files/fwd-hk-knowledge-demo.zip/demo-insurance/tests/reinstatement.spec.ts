// TAP demonstration model. Not FWD internal documentation, source code or production behavior. No real customer data. 
// Executable unit-test sketch for the adjacent demo handler; not a FWD integration test.
import { expect, test } from "vitest";
import { handle } from "../services/policy/reinstatement";

test("Reinstatement request: valid input", () => {
  expect(handle({requestId:"demo-reinstatement-valid",reviewApproved:true}).status).toBe("accepted_for_demo_review");
});
test("Reinstatement request: invalid input", () => {
  expect(() => handle({requestId:"demo-reinstatement-invalid",reviewApproved:false})).toThrow();
});
test("Reinstatement request: repeated submission", () => {
  const input = {requestId:"demo-reinstatement-retry",reviewApproved:true};
  expect(handle(input)).toBe(handle(input));
});
