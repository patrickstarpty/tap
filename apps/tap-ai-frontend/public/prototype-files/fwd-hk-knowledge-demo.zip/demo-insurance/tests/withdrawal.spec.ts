// TAP demonstration model. Not FWD internal documentation, source code or production behavior. No real customer data. 
// Executable unit-test sketch for the adjacent demo handler; not a FWD integration test.
import { expect, test } from "vitest";
import { handle } from "../services/policy/withdrawal";

test("Withdrawal quotation: valid input", () => {
  expect(handle({requestId:"demo-withdrawal-valid",quoteVersion:4}).status).toBe("accepted_for_demo_review");
});
test("Withdrawal quotation: invalid input", () => {
  expect(() => handle({requestId:"demo-withdrawal-invalid",quoteVersion:3})).toThrow();
});
test("Withdrawal quotation: repeated submission", () => {
  const input = {requestId:"demo-withdrawal-retry",quoteVersion:4};
  expect(handle(input)).toBe(handle(input));
});
