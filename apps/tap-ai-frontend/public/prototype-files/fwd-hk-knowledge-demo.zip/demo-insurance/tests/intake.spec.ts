// TAP demonstration model. Not FWD internal documentation, source code or production behavior. No real customer data. 
// Executable unit-test sketch for the adjacent demo handler; not a FWD integration test.
import { expect, test } from "vitest";
import { handle } from "../services/claims/intake";

test("Claim registration: valid input", () => {
  expect(handle({requestId:"demo-intake-valid",policyReference:"demo-policy-001"}).status).toBe("accepted_for_demo_review");
});
test("Claim registration: invalid input", () => {
  expect(() => handle({requestId:"demo-intake-invalid",policyReference:""})).toThrow();
});
test("Claim registration: repeated submission", () => {
  const input = {requestId:"demo-intake-retry",policyReference:"demo-policy-001"};
  expect(handle(input)).toBe(handle(input));
});
