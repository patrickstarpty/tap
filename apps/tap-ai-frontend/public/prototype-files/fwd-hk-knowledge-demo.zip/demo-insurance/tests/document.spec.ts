// TAP demonstration model. Not FWD internal documentation, source code or production behavior. No real customer data. 
// Executable unit-test sketch for the adjacent demo handler; not a FWD integration test.
import { expect, test } from "vitest";
import { handle } from "../services/documents/document";

test("Policy document access: valid input", () => {
  expect(handle({requestId:"demo-document-valid",ownsPolicy:true}).status).toBe("accepted_for_demo_review");
});
test("Policy document access: invalid input", () => {
  expect(() => handle({requestId:"demo-document-invalid",ownsPolicy:false})).toThrow();
});
test("Policy document access: repeated submission", () => {
  const input = {requestId:"demo-document-retry",ownsPolicy:true};
  expect(handle(input)).toBe(handle(input));
});
