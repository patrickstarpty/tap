// TAP demonstration model. Not FWD internal documentation, source code or production behavior. No real customer data. 
// Executable unit-test sketch for the adjacent demo handler; not a FWD integration test.
import { expect, test } from "vitest";
import { handle } from "../services/underwriting/underwriting";

test("Underwriting decision: valid input", () => {
  expect(handle({requestId:"demo-underwriting-valid",evidenceVersion:3}).status).toBe("accepted_for_demo_review");
});
test("Underwriting decision: invalid input", () => {
  expect(() => handle({requestId:"demo-underwriting-invalid",evidenceVersion:null})).toThrow();
});
test("Underwriting decision: repeated submission", () => {
  const input = {requestId:"demo-underwriting-retry",evidenceVersion:3};
  expect(handle(input)).toBe(handle(input));
});
