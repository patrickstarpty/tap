// TAP demonstration model. Not FWD internal documentation, source code or production behavior. No real customer data. 
// Executable unit-test sketch for the adjacent demo handler; not a FWD integration test.
import { expect, test } from "vitest";
import { handle } from "../services/policy/beneficiary";

test("Beneficiary allocation: valid input", () => {
  expect(handle({requestId:"demo-beneficiary-valid",allocationTotal:100}).status).toBe("accepted_for_demo_review");
});
test("Beneficiary allocation: invalid input", () => {
  expect(() => handle({requestId:"demo-beneficiary-invalid",allocationTotal:99})).toThrow();
});
test("Beneficiary allocation: repeated submission", () => {
  const input = {requestId:"demo-beneficiary-retry",allocationTotal:100};
  expect(handle(input)).toBe(handle(input));
});
