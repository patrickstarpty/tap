// TAP demonstration model. Not FWD internal documentation, source code or production behavior. No real customer data. 
// Minimal contract sketch, not a deployed endpoint. In-memory state is illustrative.
// Production requires authentication, durable transactions and concurrency control.
const responses = new Map<string, { status: string }>();
export function handle(input: { requestId: string; consent: unknown }) {
  if (!input.requestId) throw new Error("request_id_required");
  if (input.consent !== true) {
    throw new Error("identity_validation_failed");
  }
  const previous = responses.get(input.requestId);
  if (previous) return previous;
  const result = { status: "accepted_for_demo_review" };
  responses.set(input.requestId, result);
  return result;
}
