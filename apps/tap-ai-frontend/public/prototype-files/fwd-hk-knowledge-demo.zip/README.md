# FWD HK knowledge graph demonstration

Reviewed: 2026-09-06.

Public references: FWD HK current public product directory (38 insurance product/series entries; one health-services entry excluded) plus five online versions. These are 43 catalogue/version references, not 43 unique policy contracts. Product availability has not been independently confirmed for every distribution channel.

Sources:
- https://www.fwd.com.hk/en/products/
- https://www.fwd.com.hk/online-insurance/en/
- https://www.fwd.com.hk/online-insurance/support/en/
- https://www.fwd.com.hk/en/support/
- https://www.fwd.com.hk/en/claims/

Each public node links its source. No full policy wording is reproduced. Private/bancassurance-only products and investment funds are not represented as a complete catalogue.

Business decomposition, product-to-process mappings, internal systems, code, test cases, automation, run records and findings are curated demonstration models, not extracted FWD enterprise data.

The code and Vitest scripts are minimal illustrative sketches. They have no production authentication, durable persistence or concurrency controls. Run records and defects represent fictional historical scenarios and are not the result of executing the included snippets. No real customer information is included.

Open knowledge-graph.json for the complete node/edge model. Individual knowledge records and example code are stored by path.
