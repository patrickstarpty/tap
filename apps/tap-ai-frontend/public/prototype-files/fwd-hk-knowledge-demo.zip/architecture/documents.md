TAP demonstration model. Not FWD internal documentation, source code or production behavior. No real customer data. Versioned documents, content checksums and authorised retrieval.

Boundary: this is an illustrative module, not a discovered FWD repository or vendor platform.
Data: synthetic references only.
Observability: correlate requestId, policyId and revision; redact customer information.